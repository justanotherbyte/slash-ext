
__title__ = 'dpy-ext-slash'
__author__ = 'quiktea'
__license__ = 'MIT'
__version__ = '0.0.1a'




from discord.ext.slash.client import *